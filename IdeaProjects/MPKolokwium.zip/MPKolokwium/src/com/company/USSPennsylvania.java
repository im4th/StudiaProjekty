package com.company;

import java.util.Arrays;
import java.util.Random;

public class USSPennsylvania extends Statek{
    private Uzbrojenie TAB[];
    public USSPennsylvania(String NAZWA, int STAN ){//Uzbrojenie TAB[]) {
        super.USTAWSTAN(NAZWA,STAN);
        //this.TAB = TAB;
    }
    public void USTAWUZBROJENIE(Uzbrojenie TAB[])
    {
        this.TAB = TAB;
    }
    @Override
    public String toString()
    {
        return Arrays.toString(TAB) + super.toString();
    }

}
