package com.company;

public class Main {

    public static void main(String[] args) {
    Statek statek1= new Statek();
    Statek statek2= new Statek();
    Statek statek3= new Statek();
    Statek statek4= new Statek();
    statek2.USTAWSTAN("StatekA",1);
    statek3.USTAWSTAN("StatekB",0);
    statek4.USTAWSTAN("StatekC",0);
        System.out.println(statek1.toString());
        statek1.atakuj(statek2);
        System.out.println(statek2.toString());
    }
}
