package com.company;

public class Uzbrojenie {
    public String RODZAJ;
    public int ILOSCUZBROJENIA;

    @Override
    public String toString(){
        return "Rodzaj uzbrojenia: " + RODZAJ +  " Ilość uzbrojenia:  " + ILOSCUZBROJENIA;
    }
}
