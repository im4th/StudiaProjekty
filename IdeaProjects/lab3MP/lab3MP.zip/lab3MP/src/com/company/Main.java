package com.company;

import java.util.Scanner;

public class Main {

    private static Scanner sc;
    static String a;
    static String b;
    static char c;

    public static void main(String[] args) {
        Zadania.zad31();
    }
}
