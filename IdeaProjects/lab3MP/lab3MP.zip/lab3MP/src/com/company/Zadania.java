package com.company;

import java.util.Scanner;

public class Zadania {

    public static Scanner sc = new Scanner(System.in);

    public static void zad31(){
        String a;
        String b;
        char c;
        int j;
        //Scanner sc = new Scanner(System.in);
        j=0;
        System.out.println("Podaj String");
        a = sc.nextLine();
        System.out.println("Podaj char");
        b = sc.next();
        c = b.charAt(0);
        for(char i: a.toCharArray()) {
            if (i == c)
                j++;
        }
        System.out.println("Znak wystepuje "+ j + " razy.");
        }
    public static void zad32(){
        String wpisanyLancuch = sc.nextLine();
        for(char i:wpisanyLancuch.toCharArray()){
            if(1==1)
                ;
        }
    }
    }
